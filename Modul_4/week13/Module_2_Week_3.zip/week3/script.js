let pagination = document.getElementById('pagination');
pagination.onclick = function(event){
    if (event.target.type === "button"){
        let numberOfQuestion = event.target.dataset.question;
        let activeQuestion = document.getElementById(numberOfQuestion);
        let questions = document.getElementsByTagName('form');
        for (let i = 0; i < questions.length; i++){
            questions[i].style.display = 'none';
        }
        activeQuestion.style.display = "block";
    }
};
    

function firstTask() {

    const userStr = document.querySelector('#userInput'),
        btn = document.querySelector('#btn'),
        mountPoint = document.querySelector('.userOutput');
    
    function showStatOfStr(str) {
        let letter = 0,
            number = 0,
            simbol = 0;
        let string = str.value.split('');
        string.forEach(element => {
            if (/[a-zа-яё]/i.test(element)) {
                letter++;
            } else if (element <= 9 ){
                number++;
            } else {
                simbol++;
            }
        });
        mountPoint.innerHTML = `<li>В строке ${letter} букв, ${number} цифр, ${simbol} других знаков</li>`;
    } 

    btn.addEventListener('click',() =>{showStatOfStr(userStr);});
}


function secondTask() {
    const userStr = document.querySelector('#userInput2'),
        btn = document.querySelector('#btn2'),
        mountPoint = document.querySelector('#userOutput2'),
        units = ["", "один", "два", "три", "четыре", "пять", "шесть", "семь", "восемь", "девять"],
        teen = ["","десять", "одиннадцать", "двенадцать", "триннадцать", "четырнадцать", "пятнадцать", "шестнадцать","семнадцать", "восемнадцать", "девятнадцать"],
        dozers = ["", "", "двадцать", "тридцать", "сорок", "пятьдесят", "шестьдесят", "семьдесят", "восемьдесят", "девяносто"];

    function showResult(str){
        let result = ``,
            string = str.value;
        [first_index, second_index] = string.split('');
        console.log(first_index, second_index);
        if (string > 19) {
            result = `${dozers[first_index]} ${units [second_index]}`;
        } else if (string > 9) {
            result = `${teen[first_index]}`;
        } else if (string > 0) {
            result =`${units[first_index]}`;
        } else if (string == 0) {
            result = `ноль`;
        } else {
            result = `Введите число от 0 до 99`;
     }
         mountPoint.innerHTML = `<li>${result.toUpperCase()}</li>`;
    }

    btn.addEventListener('click',() =>{showResult(userStr);});
}

function thirdTask() {
    const userStr = document.querySelector('#userInput3'),
        btn = document.querySelector('#btn3'),
        mountPoint = document.querySelector('#userOutput3');
    
    function showChangeStr(str) {
        let string = str.value.split(''),
            arr = [];
        string.forEach(element => {
            if (/[A-ZА-ЯЁ]/.test(element)) {
               arr.push(element.toLowerCase());
            } else if (element <= 9 ){
               arr.push("_");
            } else if (/[a-zа-яё]/.test(element)){
                arr.push(element.toUpperCase());
            } else {
                arr.push(element);
            }
        });
        mountPoint.innerHTML = `${arr.join('')}`;
    }

    btn.addEventListener('click',() => {showChangeStr(userStr);});
}

function fourTask() {
    const userStr = document.querySelector('#userInput4'),
        btn = document.querySelector('#btn4'),
        mountPoint = document.querySelector('#userOutput4');
    
    function showChangeStile(str) {
        let arr = str.value.split('-'),
            value = arr.map(item => item[0].toUpperCase()+item.slice(1));
        mountPoint.innerHTML = `${value.join('')}`;
    }

    btn.addEventListener('click',() => {showChangeStile(userStr);});
}

function fiveTask() {
    const userStr = document.querySelector('#userInput5'),
        btn = document.querySelector('#btn5'),
        mountPoint = document.querySelector('#userOutput5');
    
    function showChangeStile(str) {
        let arr = str.value.split(' '),
            value = arr.map(item => item[0].toUpperCase());
        mountPoint.innerHTML = `${value.join('')}`;
    }
    btn.addEventListener('click',() => {showChangeStile(userStr);});
}

function sixTask() {
    const userStr = document.querySelector('#userInput6'),
        btn = document.querySelector('#btn6'),
        mountPoint = document.querySelector('#userOutput6');
        let  value = '';
    
    function showString(str) {
        value +=` ${str.value}`;
        mountPoint.textContent = value;
    }
    btn.addEventListener('click',() => {showString(userStr);});
}

function sevenTask() {
    const userStr = document.querySelector('#userInput7'),
        btn = document.querySelector('#btn7');
    
    function showValue(str) {
       let value = str.value,
            mountPoint = document.querySelector('#userOutput7').textContent = `${eval(value)}`; 
        // Знаю что eval опасен, просто лень писать более длинное решение :)
    }
    btn.addEventListener('click',() => {showValue(userStr);});
}

function eightTask() {
    const userStr = document.querySelector('#userInput8'),
        btn = document.querySelector('#btn8'),
        mountPoint = document.querySelector('#userOutput8');
    
    function showInfo(str) {
       arr = str.value.split('/');
       path = arr.slice(3,).join('/');
       mountPoint.textContent = `Протокол: ${arr[0]}, Домен: ${arr[2]}, Путь: /${path}`;
    }
    btn.addEventListener('click',() => {showInfo(userStr);});
}

function nineTask() {
    const userStr = document.querySelector('#userInput9'),
        delimiterInput = document.querySelector('#userInput9-2'),
        btn = document.querySelector('#btn9'),
        mountPoint = document.querySelector('#userOutput9');
    
    function showStr(str, del) {
        re =  new RegExp(`${del.value}`,'g');
        string = str.value;
       mountPoint.textContent = `${string.replace(re, ', ')}`;
    }
    btn.addEventListener('click',() => {showStr(userStr, delimiterInput);});
}

function tenTask() {
    const userStr = document.querySelector('#userInput10'),
        userParameters = document.querySelector('#userInput10-2'),
        btn = document.querySelector('#btn10'),
        mountPoint = document.querySelector('#userOutput10');
    
    function showStr(str, par) {
        let aString = str.value.split(''),
           parameters = par.value.split(','),
           value = ['', ...parameters];
        
        aString.forEach((element, i) => {
            if (element == '%'){
                aString.splice(i, 2, value[aString[i+1]]);
            }
        });

       mountPoint.textContent = aString.join('');
       console.log(value, aString);
    }
    btn.addEventListener('click',() => {showStr(userStr, userParameters);});
}

firstTask();
secondTask();
thirdTask();
fourTask();
fiveTask();
sixTask();
sevenTask();
eightTask();
nineTask();
tenTask();

