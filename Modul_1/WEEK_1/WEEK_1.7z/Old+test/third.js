module.exports = function (length) {
    let perimeter = length * 4;
    return perimeter;
}