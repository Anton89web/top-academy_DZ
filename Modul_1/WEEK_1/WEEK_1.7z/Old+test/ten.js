module.exports = function (number) { 
 return number % 2 === 0 ? 'Четное' : 'Нечетное';
};