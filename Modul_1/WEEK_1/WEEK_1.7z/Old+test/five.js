module.exports = function name (km, hour) {
    let speed = km / hour;
    return Math.floor (speed);
}
// function name (250, 3);
