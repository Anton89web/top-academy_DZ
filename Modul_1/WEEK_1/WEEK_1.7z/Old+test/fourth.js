module.exports = function (radius){
    let area = Math.floor(Math.PI * (radius ** 2));
    return area;
};
