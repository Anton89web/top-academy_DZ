module.exports = function (сurrencyConverter) {
    let dollar = сurrencyConverter * 0.90;
    return dollar;
}