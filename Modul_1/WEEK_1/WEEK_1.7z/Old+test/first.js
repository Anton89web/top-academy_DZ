
module.exports = function first(name) {
    let hello = `Привет, ${name} !`;
    return(hello);
}

 
