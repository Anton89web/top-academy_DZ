module.exports = function (yearBorn){
    let age = 2022 - yearBorn;
    return(age);
}